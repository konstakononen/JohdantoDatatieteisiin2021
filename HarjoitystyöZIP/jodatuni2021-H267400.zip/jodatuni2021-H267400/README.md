# JohdantoDatatieteisiin2021

Mukana olevat tiedostot
Notebookit:
- Liiga_CombineTables.ipynb
- Liiga_GetPlayerInformation.ipynb
- Liiga_GetPlayersSalariesBySeason.ipynb
- Liiga_GetPlayersStatsBySeason.ipynb
- Liiga_MachineLearning.ipynb
- Liiga_MasterNotebook.ipynb
CSVt:
- Liiga_Players_AllData
- LiigaKaudet
- PelaajaPalkat
- Player_Information
- PlayersSalaries_By_Season
- PlayerStats_By_Season


Harjoitustyön käyttämisen ohje: 

- Harjoitustyötä ajetaan Liiga_MasterNotebookista
  	--> Huom: Datan latauksia tekevät notebookit tallentavat tiedostot kehittäjän koneelle määritettyyn polkuun
  	--> polut pitää määrittää käyttäjän koneelle sopiviksi

- Harjoitustyötä voi ajaa myös jokaisesta notebookista kerrallaan, koska tiedostot on zip-tiedoston mukana 
	--> ei tarvitse käyttää masteria
	--> laita datan tallennus solut kommenttiin, niin notebook ei kaadu

- Liiga_CombineTables.ipynb ja Liiga_MachineLearning.ipynb ovat sellaisia, jotka tuottavat graafeja
